# Kopi Lab SPA (React + Vite + Tailwind)

Snippet GTM (`GTM-5CZM33JH`) dipasang **sekali** di `index.html`. Ganti ID bila perlu (2 tempat: script dan noscript).
Karena SPA, tiap pindah halaman mengirim event `spa_page_view` (page_path, page_title, page_type) ke dataLayer. Pakai event ini sebagai trigger Custom Event di GTM untuk pageview GA4.

## Jalankan lokal
npm install && npm run dev

## Deploy ke GitHub Pages
1. Buat repo, upload seluruh isi folder ini (tanpa node_modules), branch `main`.
2. Settings > Pages > Source: **GitHub Actions**.
3. Push; workflow `.github/workflows/deploy.yml` build dan publish otomatis. `404.html` dibuat otomatis agar URL langsung (refresh) tetap jalan.

## URL
/content/contentArticle/{slug} · /content/contentVideoArticle/{slug}
/simple_engagement/{carousel|text_subm|media_subm|audio_subm|puzzle}/{slug}
/games/{tap-cepat|memory|tebak-angka}/{slug} · /quiz/{kategori}/{slug}

## Event dataLayer
spa_page_view, select_content, klik_cta, filter_content, share_click, carousel_slide, submission_success, puzzle_win, game_score, quiz_answer, quiz_complete

## Mengedit konten
Semua di `src/data.js`. Cerita artikel dibuat otomatis dari kumpulan kalimat (placeholder); ID video YouTube ada di konstanta `YT`.
